
#!/bin/bash
# Set up cron job to run crawler every 14 days and email summary

echo "0 9 */14 * * python /app/autism_employment_full_crawler.py >> /var/log/autism_crawler.log 2>&1" > cronjob
crontab cronjob
cron && tail -f /var/log/autism_crawler.log
